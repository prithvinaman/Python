import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("/Users/prithvinaman/Documents/INT375/Dataset1.csv")

# Preprocess date and create additional columns
df['Date'] = pd.to_datetime(df['Year'].astype(str) + '-' + df['Month'].astype(str), errors='coerce')
df['Year-Month'] = df['Date'].dt.to_period('M')

# -------------------- TEXTUAL INSIGHTS --------------------
print("----- TEXTUAL INSIGHTS -----")

# 1. Total number of records
print("1. Total number of records:", len(df))

# 2. Number of unique zones
print("2. Number of unique zones:", df['ZoneName'].nunique())

# 3. Year with highest death registrations
yearly_deaths = df.groupby('Year')['DeathRegCount'].sum()
max_year = yearly_deaths.idxmax()
max_val = yearly_deaths.max()
print(f"3. Year with highest death registrations: {max_year} ({max_val} deaths)")

# 4. Average certificates issued per month
avg_cert_month = df['CertiIssueCount'].mean()
print(f"4. Average certificates issued per month: {avg_cert_month:.2f}")

# 5. Month with the lowest death registrations
min_row = df.loc[df['DeathRegCount'].idxmin()]
print(f"5. Month with lowest death registrations: {min_row['Month']}-{min_row['Year']} ({min_row['DeathRegCount']} deaths)")

# 6. Zone with most consistent death registrations (lowest std)
zone_std = df.groupby('ZoneName')['DeathRegCount'].std()
most_consistent_zone = zone_std.idxmin()
print(f"6. Zone with most consistent registrations: {most_consistent_zone} (Std Dev: {zone_std.min():.2f})")

# 7. Certificate issuance efficiency (CertiIssued / DeathReg)
efficiency = (df['CertiIssueCount'].sum() / df['DeathRegCount'].sum()) * 100
print(f"7. Overall certificate issuance efficiency: {efficiency:.2f}%")

# 8. Month with highest certificate issuance
max_cert = df.loc[df['CertiIssueCount'].idxmax()]
print(f"8. Highest certificate issuance: {max_cert['CertiIssueCount']} in {max_cert['Month']}-{max_cert['Year']}")

# 9. Records with more female than male certificates
female_more = df[df['CertiIssueCountFeMale'] > df['CertiIssueCountMale']]
print(f"9. Records with more female certificates than male: {len(female_more)}")

# 10. Zone with highest total death registrations
zone_death_total = df.groupby('ZoneName')['DeathRegCount'].sum()
top_zone = zone_death_total.idxmax()
print(f"10. Zone with highest death registrations: {top_zone} ({zone_death_total.max()} deaths)")

# -------------------- VISUAL INSIGHTS --------------------
sns.set(style="whitegrid")

# Chart 1: Certificates Issued by Gender
plt.figure(figsize=(8, 6))
df[['CertiIssueCountMale', 'CertiIssueCountFeMale']].sum().plot(kind='bar', color=['skyblue', 'lightpink'])
plt.title("Certificates Issued by Gender")
plt.ylabel("Count")
plt.show()

# Chart 2: Trend of Death Registrations Over Time
plt.figure(figsize=(10, 6))
df.groupby('Date')['DeathRegCount'].sum().plot(color='green')
plt.title("Trend of Death Registrations Over Time")
plt.xlabel("Date")
plt.ylabel("Death Registrations")
plt.grid(True)
plt.show()

# Chart 3: Top 5 Months with Highest Certificate Issues
plt.figure(figsize=(8, 6))
top5_months = df.groupby('Year-Month')['CertiIssueCount'].sum().sort_values(ascending=False).head(5)
top5_months.plot(kind='bar', color='orchid')
plt.title("Top 5 Months with Highest Certificate Issues")
plt.ylabel("Certificates Issued")
plt.xticks(rotation=45)
plt.show()

# Chart 4: Zone-wise Average Death Registrations
plt.figure(figsize=(10, 6))
zone_avg = df.groupby('ZoneName')['DeathRegCount'].mean().sort_values()
zone_avg.plot(kind='barh', color='orange')
plt.title("Zone-wise Average Death Registrations")
plt.xlabel("Average Registrations")
plt.show()

# Chart 5: Correlation Heatmap
plt.figure(figsize=(10, 8))
numeric_cols = df.select_dtypes(include='number')
sns.heatmap(numeric_cols.corr(), annot=True, cmap='coolwarm', fmt=".2f")
plt.title("Correlation Heatmap")
plt.show()

# Chart 6: Certificates vs Death Registrations (Scatter Plot)
plt.figure(figsize=(10, 6))
plt.scatter(df['DeathRegCount'], df['CertiIssueCount'], alpha=0.5)
plt.title("Certificates vs Death Registrations")
plt.xlabel("Death Registrations")
plt.ylabel("Certificates Issued")
plt.show()

# Chart 7: Yearly Certificates Issued (Area Chart)
plt.figure(figsize=(10, 6))
df.groupby('Year')['CertiIssueCount'].sum().plot(kind='area', color='lightgreen', alpha=0.7)
plt.title("Certificates Issued Over the Years")
plt.xlabel("Year")
plt.ylabel("Total Certificates Issued")
plt.grid(True)
plt.show()
